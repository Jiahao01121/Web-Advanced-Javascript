web
├── README.md
│
├── assets
│   ├── footer-02.png (footer logo)
│   ├── black_logo_new-06.png (header logo)
│   ├── Miller-DisplayRomanSC.otf
│
├── index.html
├── style_second_solution.css (use this one)
├── style.css (the stylesheet for different typeface implement, (discarded.))
├── d3v4+jetpack.js (dependencies)
├── graph-scroll.js (dependencies)
└── index.js
